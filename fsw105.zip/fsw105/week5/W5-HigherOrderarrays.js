/*function fiveAndGreaterOnly(arr)
{
    // your code here
    const result = arr.filter(function(number){
        if (number >= 5){
            return number;
        }
    });
    return result;
} // close function

console.log("--- Array Filter #1 ---");
console.log(fiveAndGreaterOnly([3, 6, 8, 2]));  // Output: [6, 8]

function evensOnly(arr)
{
    const result = arr.filter(function(number){
        if (number % 2 == 0){
            return true;
        }
    });
    return result;
} 

console.log("--- Array Filter #2 ---");
console.log(evensOnly([3, 6, 8, 2]));


function doubleNumbers(arr)
{
    const result = arr.map(function(number){
        return number * 2;
    })
    return result;
} // close function

console.log("---  Array Map #1 ---");
console.log(doubleNumbers([2, 5, 100]));  // Output: [4, 10, 200]


function stringItUp(arr){
    const result = arr.map(function(stringval){
        return stringval.toString();
    });
    return result;
}

console.log("---  Array Map #2 ---");
console.log(stringItUp([2, 5, 100]));  // Output: ["2", "5", "100"]


function capitalizeNames(arr){
    const result = arr.map(function(stringVal){
        return stringVal.charAt(0).toUpperCase() + stringVal.slice(1).toLowerCase();
    })
    return result;
}

console.log("---  Array Map #3 ---"); 
console.log(capitalizeNames(["john", "JACOB", "jinGleHeimer", "schmidt"]));



function total(arr)
{
    const result = arr.reduce(function(number, addedValue){
        addedValue = addedValue + number;
        return addedValue
    });
    return result;
}

console.log("---  Array Reduce #1 ---");
console.log(total([1, 2, 3]));


function stringConcat(arr) {
    const result = arr.reduce(function(number, addedValue){
        addedValue = number + addedValue.toString()
        return addedValue;
    });
    return result;
}

console.log("---  Array Reduce #2 ---")
console.log(stringConcat([1, 2, 3]));   // Output: "123"


function totalVoters(arr){
    const result = arr.reduce(function(n, voter){
       return n + (voter.voted == true)
    },0);
    return result;
    
}

var voters = [
    {name: 'Bob' , age: 30, voted: true},
    {name: 'Jake' , age: 32, voted: true},
    {name: 'Kate' , age: 25, voted: false},
    {name: 'Sam' , age: 20, voted: false},
    {name: 'Phil' , age: 21, voted: true},
    {name: 'Ed' , age: 55, voted: true},
    {name: 'Tami' , age: 54, voted: true},
    {name: 'Mary' , age: 31, voted: false},
    {name: 'Becky' , age: 43, voted: false},
    {name: 'Joey' , age: 41, voted: true},
    {name: 'Jeff' , age: 30, voted: true},
    {name: 'Zack' , age: 19, voted: false},
];

console.log("---  Array Reduce #3 ---")
console.log( totalVoters(voters) );  // Output: 7


function leastToGreatest(arr) {
    const result = arr.sort(function(a,b){
        return a - b;
    })
    return result
}

console.log("---  Array Sort #1 ---");
console.log( leastToGreatest([1, 3, 5, 2, 90, 20]) );  //Output: [1, 2, 3, 5, 20, 90]


function  greatestToLeast(arr){
    const result = arr.sort(function(a,b){
        return b - a;
    })
    return result
    
}

console.log("---  Array Sort #2 ---")
console.log(greatestToLeast([1, 3, 5, 2, 90, 20]));  // Output: [90, 20, 5, 3, 2, 1]
*/

function lengthSort(arr) {
    const result = arr.sort(function(a,b){
        return a.length - b.length;
    });
    return result;
}

console.log("---  Array Sort #3 ---")
console.log(lengthSort(["dog", "wolf", "by", "family", "eaten"]));  // Output: ["by", "dog", "wolf", "eaten", "family"]