//Preliminaries

//5 is greater than 3 Statement
if (5 > 3);{
    console.log("5 is greater than 3")
}

// Cat is greater than 3 Statement
var cat = {
    length: 3
};

if (cat.length = 3){
    console.log("cat is the length of 3")
}

//Cat Dog if else statement

var Cat;
var Dog;

if (Cat = Dog){
    console.log("They are the same")
}
else{
    console.log("Cat and Dog are not the same")
}




