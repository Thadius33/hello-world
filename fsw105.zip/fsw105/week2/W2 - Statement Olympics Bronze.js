//Bronze

//if Bobby is 18 or older
var person = {
    firstName: "Bobby",
    age: 12
};

if (person.age >= 18){
    console.log("Bobby is allowed to go to the movie");
}
else{
    console.log("Bobby is not allowed to got to the movies");
}

// name start with B 
var person = {
    firstName: "Bobby",
    age: 12
};

if ( person.firstName.charAt(0) === "B") {
    console.log("They are allowed in the movies" );
}

// 18 and name starts with B

var person = {
    firstName: "Bobby",
    age: 12
};

if ((person.age >= 18) && ( person.firstName.charAt(0) === "B")){
    console.log("They are allowed in the movies");
}
else{
    console.log("They are not allowed in the movies");SDQ1DBFHQ1T QWA89IW[PBWQ]
}
