
var i = 1;

if(i === 1){
    console.log("Strict");
}
else if (i == 1){
    console.log("loose or abstract");
}
else {
    console.log("not equal at all");
}

// 2.if statement prints yes
// Am I suppose to get this to say yes even though 2 does not = 4?


if ((1 <= 2) && (2 == 4)){
    console.log("yes")
}