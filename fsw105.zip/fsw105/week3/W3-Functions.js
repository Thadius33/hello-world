// 1
function add(a, b){
    return a + b;
}

var sum = add(5, 5);
console.log("Sum is: " + sum)

// 2
function Maximum(a, b, c){
    return Math.max(a, b, c);
}

var max = Maximum(5, 6, 8);
console.log("Max is: " + max)

// 3
function even(a){
    if(a % 2 == 0){
    return "Even";
    }
    else 
    return "odd";
}

var odd = even(3);
console.log("Number is: " + odd)

// 4
function string(message){
    if(message.length <= 20){
        return message + message;
    }
    else 
    return message.slice(0, message.length / 2);
}

var str = string("helloEarthWorldGreats");
console.log(str);


