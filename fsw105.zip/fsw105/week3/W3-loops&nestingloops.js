/*var officeItems = ["stapler", "monitor", "computer", "desk", "lamp", "computer", "lamp", "stapler", "computer", "computer"];
var count = 0;

for (var i = 0; i < officeItems.length; i++){
    if (officeItems[i] === "computer"){
        count++;
    }
}
console.log(count);  // -> 48

var peopleWhoWantToSeeMadMaxFuryRoad = [
    {
        name: "Mike",
        age: 12,
        gender: "male"
    }, {
        name: "Madeline",
        age: 80,
        gender: "female"
    }, {
        name: "Cheryl",
        age: 22,
        gender: "female"
    }, {
        name: "Sam",
        age: 30,
        gender: "male"
    }, {
        name: "Suzy",
        age: 4,
        gender: "female"
    }
];

// Loop #1 
function isOldEnough(){
    for (var i = 0; i < peopleWhoWantToSeeMadMaxFuryRoad.length; i++){
        if (peopleWhoWantToSeeMadMaxFuryRoad[i].age >= 18){
            console.log("old enough");
        }
        else
        console.log("not old enough")
    }    
}

isOldEnough();

//loop #2
function isOldEnoughWithName(){
    for (var i = 0; i < peopleWhoWantToSeeMadMaxFuryRoad.length; i++){
        if (peopleWhoWantToSeeMadMaxFuryRoad[i].age >= 18){
            console.log(peopleWhoWantToSeeMadMaxFuryRoad[i].name + " is old enough to see Mad Max");
        }
        else
        console.log( peopleWhoWantToSeeMadMaxFuryRoad[i].name + " is not old enough to see Mad Max")
    }    
}
isOldEnoughWithName();

// Loop #3

function isOldEnoughWithNameAndGender(){
    for (var i = 0; i < peopleWhoWantToSeeMadMaxFuryRoad.length; i++){
        if ((peopleWhoWantToSeeMadMaxFuryRoad[i].age >= 18 && peopleWhoWantToSeeMadMaxFuryRoad[i].gender === "male")){
            console.log(peopleWhoWantToSeeMadMaxFuryRoad[i].name + " is old enough.  He's good to see Mad Max Fury Road");
        }
        else if ((peopleWhoWantToSeeMadMaxFuryRoad[i].age >= 18 && peopleWhoWantToSeeMadMaxFuryRoad[i].gender === "female")){
            console.log(peopleWhoWantToSeeMadMaxFuryRoad[i].name + " is old enough.  She's good to see Mad Max Fury Road");
        }
        else if ((peopleWhoWantToSeeMadMaxFuryRoad[i].age <= 18 && peopleWhoWantToSeeMadMaxFuryRoad[i].gender === "male")){
            console.log(peopleWhoWantToSeeMadMaxFuryRoad[i].name + " is not old enough to see Mad Max Fury Road, don't let Him in");
        }
        else
            console.log(peopleWhoWantToSeeMadMaxFuryRoad[i].name + " is not old enough to see Mad Max Fury Road, don't let Her in")
    }    
}
isOldEnoughWithNameAndGender();*/

// Loop 4

let a;

a = [...Array(100).keys()]

function isEvenOrOdd (){
    for (var i = 0; i < a.length; i++){
        if ((a[i] <= 100 && a[i] % 2 == 0 )){
            console.log("Even");
    }
    else{
        console.log("odd");
    }
    }
}

isEvenOrOdd();
