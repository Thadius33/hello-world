var shopper = {
    firstName: "Thadius",
    middleName: "Donell",
    lastName : "Vannburan",
    age      : 26,
    haveCash: false,
    cart    : ["Sugar", " Crackers", " Cheese"],
    fullName : function() {
        return this.firstName + " " + this.middleName + " " + this.lastName;
    }
  };

  console.log(shopper.fullName() + " has " + shopper.cart + " in his buggie.");

