/*function capitalizeAndLowercase(str){
    var upperlower = str.toUpperCase() + str.toLowerCase();
    return upperlower;
}

console.log(capitalizeAndLowercase("Hello"));
*/
function findMiddleIndex(str){
    var midString = Math.floor(str.length / 2);
    return midString;
}

console.log(findMiddleIndex("Getting"))

function returnFirstHalf(str){
    var halfway = str.slice(0, Math.floor(str.length / 2));
    return halfway;
}

console.log(returnFirstHalf("Hello"))

function capitalizeAndLowercase(message){
        var half = message.slice(0, Math.floor(message.length / 2));
        return half.toUpperCase() + message.slice(message.length/ 2).toLowerCase();
    }


console.log(capitalizeAndLowercase("Hellos"))


//return half.toUpperCase() + message.slice(2,5 );







//function string(message){
//    if(message.length <= 20){
//        return message + message;
//    }
//    else 
//    return message.slice(0, message.length / 2);
//}

//var str = string("helloEarthWorldGreats");
//console.log(str);
